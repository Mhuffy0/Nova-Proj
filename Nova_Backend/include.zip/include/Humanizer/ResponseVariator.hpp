#pragma once
#include <string>
#include <vector>
#include <map>
#include <set>
#include <queue>
#include <deque>
#include <random>
#include <sqlite3.h>
#include "../Core/NeuralNet.hpp"
#include "../Core/WordVectorHelper.hpp"
#include "../Core/TopicExtractor.hpp"
#include "../Humanizer/ContextTracker.hpp"

class ResponseVariator {
public:
    ResponseVariator();
    std::string getResponse(const std::string& input);
    void addResponse(const std::string& input, const std::string& response);
    void updateConfidence(const std::string& response, bool positive);
    std::string getFallbackResponse() const;
    void startTeachingMode();
    void stopTeachingMode();
    bool isTeaching() const;
    std::vector<std::string> extractTopics(const std::string& input);
    void teachAlternative(const std::string& topic, const std::string& altResponse);
    std::string getFollowupSuggestion();
    void bulkTeachFromCSV(const std::string& filepath);

private:
    void loadDatabase();
    void saveResponse(const std::string& input, const std::string& response, float confidence);
    void createTablesIfNotExist();

    std::string lastUsedResponse;
    sqlite3* db = nullptr;
    std::map<std::string, std::vector<std::pair<std::string, float>>> knowledgeBase;
    std::map<std::string, std::set<std::string>> topicMap;
    std::set<std::string> askedQuestions;
    std::deque<std::string> contextMemory;
    std::default_random_engine rng;
    bool teachingMode = false;
    std::string fallbackResponse = "I don't know yet.";
    NeuralNet neuralNet;
    std::string lastTopic;
    ContextTracker contextTracker;

    void addToContext(const std::string& message);
    std::string summarizeContext() const;
    std::string lastFollowup = "";
};