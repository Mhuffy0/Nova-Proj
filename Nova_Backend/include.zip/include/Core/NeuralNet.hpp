#pragma once
#include <string>
#include <vector>
#include <unordered_map>
#include <cmath>
#include <sqlite3.h>

class NeuralNet {
public:
    NeuralNet();
    std::vector<float> vectorize(const std::string& input);
    void reinforce(const std::string& input, const std::string& response);
    void train(const std::string& input, const std::string& response);  // Train the network

private:
    void ensureTable();
    std::vector<float> getRandomVector();
    void storeTokenVector(const std::string& token, const std::vector<float>& vector);
    std::vector<float> getTokenVector(const std::string& token);  // Get vector for a token (word)
    void updateTokenVector(const std::string& token, const std::vector<float>& update);  // Update token vector
    int embeddingSize = 3;  // You can increase this for more detailed vectors
    std::unordered_map<std::string, std::vector<float>> wordEmbeddings;  // Store token embeddings
    sqlite3* db;
    std::unordered_map<std::string, std::vector<float>> responseEmbeddings;  // Store response vectors
};