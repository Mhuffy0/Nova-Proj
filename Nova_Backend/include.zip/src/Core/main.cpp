#include "../../include/Humanizer/ResponseVariator.hpp"
#include <iostream>
#include <string>
#include <algorithm>

std::string trim(const std::string& str) {
    auto first = str.find_first_not_of(' ');
    if (first == std::string::npos) return "";
    auto last = str.find_last_not_of(' ');
    return str.substr(first, (last - first + 1));
}

int main() {
    try {
        ResponseVariator bot;
        std::cout << "=== Nova AI Chat ===" << std::endl;
        std::cout << "Commands:" << std::endl;
        std::cout << "- teach: Teaching mode" << std::endl;
        std::cout << "- stop: Exit teaching mode" << std::endl;
        std::cout << "- exit: Quit" << std::endl << std::endl;

        while (true) {
            std::cout << "you: ";
            std::string input;
            std::getline(std::cin, input);
            input = trim(input);
            if (input.empty()) continue;

            std::string lower = input;
            std::transform(lower.begin(), lower.end(), lower.begin(), ::tolower);

            if (lower == "exit") break;
            if (lower == "teach") {
                bot.startTeachingMode();
                std::cout << "Nova: Teaching mode enabled." << std::endl;
                continue;
            }
            if (lower == "stop") {
                bot.stopTeachingMode();
                std::cout << "Nova: Teaching mode disabled." << std::endl;
                continue;
            }

            std::string response = bot.getResponse(input);

            if (response == bot.getFallbackResponse()) {
                std::cout << "Nova: I don't know what to say. Teach me: ";
                std::string teach;
                std::getline(std::cin, teach);
                teach = trim(teach);
                if (!teach.empty()) {
                    bot.addResponse(input, teach);
                    std::cout << "Nova: Got it!" << std::endl;
                    response = teach;
                }
            } else if (bot.isTeaching()) {
                std::cout << "Nova [Teaching]: I'd say: " << response << std::endl;
                std::cout << "Teach me a better one (or Enter to skip): ";
                std::string alt;
                std::getline(std::cin, alt);
                alt = trim(alt);
                if (!alt.empty()) {
                    auto topics = bot.extractTopics(input);
                    std::string topic = topics.empty() ? input : topics[0];
                    bot.teachAlternative(topic, alt);
                    std::cout << "Nova: Added!" << std::endl;
                    response = alt;
                }
            }

            std::cout << "Nova: " << response << std::endl;
            if (!bot.isTeaching() && response != bot.getFallbackResponse()) {
                std::cout << "Was this good? (y/n/skip): ";
                std::string fb;
                std::getline(std::cin, fb);
                fb = trim(fb);
                if (!fb.empty()) {
                    char f = tolower(fb[0]);
                    if (f == 'y') bot.updateConfidence(response, true);
                    else if (f == 'n') bot.updateConfidence(response, false);
                }
            }
        }
    } catch (const std::exception& e) {
        std::cerr << "Error: " << e.what() << std::endl;
        return 1;
    }
    return 0;
}