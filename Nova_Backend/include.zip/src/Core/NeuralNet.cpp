#include "../../include/Core/NeuralNet.hpp"
#include <sqlite3.h>
#include <sstream>
#include <cctype>
#include <map>
#include <algorithm>
#include <iostream>

NeuralNet::NeuralNet() {
    // Open the SQLite database (replace with your db file path)
    if (sqlite3_open("chatbot.db", &db) != SQLITE_OK) {
        std::cerr << "Can't open database: " << sqlite3_errmsg(db) << std::endl;
    }
    ensureTable();  // Ensure that the necessary table exists when the object is created
}

void NeuralNet::ensureTable() {
    const char* createTableQuery = R"(
        CREATE TABLE IF NOT EXISTS word_vectors (
            word TEXT PRIMARY KEY,
            vector BLOB
        );
    )";
    
    char* errMessage;
    if (sqlite3_exec(db, createTableQuery, nullptr, nullptr, &errMessage) != SQLITE_OK) {
        std::cerr << "Error creating table: " << errMessage << std::endl;
        sqlite3_free(errMessage);
    } else {
        std::cout << "Table 'word_vectors' ensured in the database." << std::endl;
    }
}

// Vectorize the user input into a numerical representation (e.g., using word embeddings)
std::vector<float> NeuralNet::vectorize(const std::string& input) {
    std::vector<float> vectorSum(embeddingSize, 0.0f);
    int wordCount = 0;

    // Break input into words and average their vector representations
    std::istringstream iss(input);
    std::string word;
    while (iss >> word) {
        auto wordVector = getTokenVector(word);
        for (int i = 0; i < embeddingSize; ++i) {
            vectorSum[i] += wordVector[i];
        }
        wordCount++;
    }

    // Average the word vectors
    for (int i = 0; i < embeddingSize; ++i) {
        vectorSum[i] /= wordCount;
    }
    return vectorSum;
}

// Get the vector for a word, if it exists; otherwise, create a new one
std::vector<float> NeuralNet::getTokenVector(const std::string& token) {
    // Check in memory first (if you have an in-memory cache, or fallback to DB)
    if (wordEmbeddings.find(token) != wordEmbeddings.end()) {
        return wordEmbeddings[token];
    }

    // Try retrieving the vector from the SQLite database
    const char* sql = "SELECT vector FROM word_vectors WHERE word = ?;";
    sqlite3_stmt* stmt;
    std::vector<float> vector;
    
    if (sqlite3_prepare_v2(db, sql, -1, &stmt, nullptr) == SQLITE_OK) {
        sqlite3_bind_text(stmt, 1, token.c_str(), -1, SQLITE_STATIC);
        if (sqlite3_step(stmt) == SQLITE_ROW) {
            // Retrieve the vector and deserialize it
            const char* vecData = reinterpret_cast<const char*>(sqlite3_column_text(stmt, 0));
            std::string vecString(vecData);  // Convert to string
            std::istringstream vecStream(vecString);
            float val;
            while (vecStream >> val) {
                vector.push_back(val);
            }
        }
        sqlite3_finalize(stmt);
    }

    // If no vector found, create a random one (as a fallback)
    if (vector.empty()) {
        vector = getRandomVector();
        storeTokenVector(token, vector);
    }

    return vector;
}

// Update the word embedding for a token in memory
void NeuralNet::updateTokenVector(const std::string& token, const std::vector<float>& update) {
    wordEmbeddings[token] = update;
    storeTokenVector(token, update);  // Also store the updated vector in the DB
}

// Method to reinforce the embeddings with positive or negative feedback (this is just an example of updating)
void NeuralNet::reinforce(const std::string& input, const std::string& response) {
    auto inputVec = vectorize(input);
    auto responseVec = vectorize(response);

    // "Reinforce" the embeddings with positive feedback (adjust vector slightly)
    for (int i = 0; i < embeddingSize; ++i) {
        inputVec[i] += 0.1f;  // Small increment for positive feedback (this can be adjusted)
        responseVec[i] += 0.1f;
    }

    // Update the vectors after reinforcement
    updateTokenVector(input, inputVec);
    updateTokenVector(response, responseVec);
}

// Train the neural net using input-response pairs
void NeuralNet::train(const std::string& input, const std::string& response) {
    // Refine the training process over time (e.g., store training pairs and update embeddings)
    reinforce(input, response);  // Update the vectors using feedback
}

// Helper function to generate a random vector (for unseen words)
std::vector<float> NeuralNet::getRandomVector() {
    std::vector<float> randomVector(embeddingSize, 0.0f);
    for (int i = 0; i < embeddingSize; ++i) {
        randomVector[i] = static_cast<float>(rand()) / RAND_MAX;  // Random float between 0 and 1
    }
    return randomVector;
}

// Helper function to store the word vector into the SQLite database
void NeuralNet::storeTokenVector(const std::string& token, const std::vector<float>& vector) {
    const char* sql = "INSERT OR REPLACE INTO word_vectors (word, vector) VALUES (?, ?);";
    sqlite3_stmt* stmt;

    // Convert vector into a string for storage
    std::ostringstream vecStream;
    for (float val : vector) {
        vecStream << val << " ";  // Serialize as space-separated values
    }

    std::string vectorData = vecStream.str();

    if (sqlite3_prepare_v2(db, sql, -1, &stmt, nullptr) == SQLITE_OK) {
        sqlite3_bind_text(stmt, 1, token.c_str(), -1, SQLITE_STATIC);
        sqlite3_bind_text(stmt, 2, vectorData.c_str(), -1, SQLITE_STATIC);
        sqlite3_step(stmt);
        sqlite3_finalize(stmt);
    }
}
