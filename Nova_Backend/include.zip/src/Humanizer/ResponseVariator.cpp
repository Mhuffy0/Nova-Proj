#include "../../include/Humanizer/ResponseVariator.hpp"
#include <iostream>
#include <fstream>
#include <sstream>
#include <algorithm>
#include <filesystem>
#include <random>

ResponseVariator::ResponseVariator() {
    rng.seed(std::random_device{}());
    createTablesIfNotExist();
    loadDatabase();
}

void ResponseVariator::createTablesIfNotExist() {
    if (sqlite3_open("chatbot.db", &db) != SQLITE_OK) {
        std::cerr << "DB error: " << sqlite3_errmsg(db) << std::endl;
        return;
    }

    const char* responseTable = R"(
        CREATE TABLE IF NOT EXISTS responses (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            topic TEXT,
            response TEXT,
            confidence REAL,
            use_count INTEGER DEFAULT 1,
            created_at TEXT DEFAULT CURRENT_TIMESTAMP
        );
    )";

    const char* vectorTable = R"(
        CREATE TABLE IF NOT EXISTS word_vectors (
            token TEXT PRIMARY KEY,
            v1 REAL, v2 REAL, v3 REAL
        );
    )";

    char* err;
    if (sqlite3_exec(db, responseTable, 0, 0, &err) != SQLITE_OK ||
        sqlite3_exec(db, vectorTable, 0, 0, &err) != SQLITE_OK) {
        std::cerr << "SQL error: " << err << std::endl;
        sqlite3_free(err);
    }
}

void ResponseVariator::loadDatabase() {
    const char* sql = "SELECT topic, response, confidence FROM responses;";
    sqlite3_stmt* stmt;
    if (sqlite3_prepare_v2(db, sql, -1, &stmt, nullptr) == SQLITE_OK) {
        while (sqlite3_step(stmt) == SQLITE_ROW) {
            std::string topic = reinterpret_cast<const char*>(sqlite3_column_text(stmt, 0));
            std::string response = reinterpret_cast<const char*>(sqlite3_column_text(stmt, 1));
            float confidence = static_cast<float>(sqlite3_column_double(stmt, 2));
            knowledgeBase[topic].emplace_back(response, confidence);

            for (const auto& extracted : extractTopics(topic)) {
                topicMap[extracted].insert(response);
            }
        }
        sqlite3_finalize(stmt);
    }
}

std::string ResponseVariator::getResponse(const std::string& input) {
    auto inputVec = WordVectorHelper::averageVectorFromInput(db, input);
    std::string bestMatch;
    float bestScore = 0.0f;

    // Get relevant context messages from ContextTracker
    std::vector<std::string> context = contextTracker.getRelevantContext();

    // Consider each response in knowledgeBase and calculate similarity
    for (const auto& [key, responses] : knowledgeBase) {
        auto keyVec = WordVectorHelper::averageVectorFromInput(db, key);
        float inputSim = WordVectorHelper::cosineSimilarity(inputVec, keyVec);

        // Adjust the score based on context relevance (context weighting)
        float totalSim = inputSim * 0.7f;  // Base similarity from input
        for (const auto& msg : context) {
            auto ctxVec = WordVectorHelper::averageVectorFromInput(db, msg);
            totalSim += WordVectorHelper::cosineSimilarity(ctxVec, keyVec) * 0.3f; // Adjust by context
        }

        if (totalSim > bestScore) {
            bestScore = totalSim;
            bestMatch = key;
        }
    }

    // Select the best match from knowledgeBase and generate response
    if (bestScore > 0.5f && !bestMatch.empty()) {
        const auto& responses = knowledgeBase[bestMatch];
        if (!responses.empty()) {
            std::vector<double> weights;
            for (const auto& r : responses) {
                weights.push_back(r.second);
            }
            std::discrete_distribution<int> dist(weights.begin(), weights.end());
            std::string result = responses[dist(rng)].first;

            contextTracker.addMessage(input);  // Add input to context
            contextTracker.addMessage(result); // Add result to context
            return result + "\n" + getFollowupSuggestion();
        }
    }

    return fallbackResponse;
}



void ResponseVariator::addResponse(const std::string& topic, const std::string& response) {
    saveResponse(topic, response, 1.0f);
    knowledgeBase[topic].emplace_back(response, 1.0f);
    for (const auto& t : extractTopics(topic)) {
        topicMap[t].insert(response);
    }
    neuralNet.train(topic, response);
}

void ResponseVariator::saveResponse(const std::string& topic, const std::string& response, float confidence) {
    const char* sql = R"(
        INSERT INTO responses (topic, response, confidence, use_count, created_at)
        VALUES (?, ?, ?, 1, datetime('now'))
    )";
    sqlite3_stmt* stmt;
    if (sqlite3_prepare_v2(db, sql, -1, &stmt, nullptr) == SQLITE_OK) {
        sqlite3_bind_text(stmt, 1, topic.c_str(), -1, SQLITE_STATIC);
        sqlite3_bind_text(stmt, 2, response.c_str(), -1, SQLITE_STATIC);
        sqlite3_bind_double(stmt, 3, confidence);
        sqlite3_step(stmt);
        sqlite3_finalize(stmt);
    }
}

void ResponseVariator::updateConfidence(const std::string& response, bool positive) {
    for (auto& [input, responses] : knowledgeBase) {
        for (auto& [resp, score] : responses) {
            if (resp == response) {
                score += positive ? 0.1f : -0.1f;
                score = std::clamp(score, 0.1f, 5.0f);
            }
        }
    }
}

std::string ResponseVariator::getFallbackResponse() const {
    return fallbackResponse;
}

void ResponseVariator::startTeachingMode() { teachingMode = true; }
void ResponseVariator::stopTeachingMode() { teachingMode = false; }
bool ResponseVariator::isTeaching() const { return teachingMode; }

std::vector<std::string> ResponseVariator::extractTopics(const std::string& input) {
    return WordVectorHelper::tokenize(input);
}


void ResponseVariator::teachAlternative(const std::string& topic, const std::string& altResponse) {
    topicMap[topic].insert(altResponse);
    saveResponse(topic, altResponse, 0.5f);
}

std::string ResponseVariator::getFollowupSuggestion() {
    // Only suggest follow-up if the current response is relevant and confident
    if (lastTopic.empty() || !topicMap.count(lastTopic) || topicMap[lastTopic].size() < 2) {
        return "";  // Avoid follow-up if no meaningful topic or only one response
    }

    std::vector<std::string> pool(topicMap[lastTopic].begin(), topicMap[lastTopic].end());
    std::shuffle(pool.begin(), pool.end(), rng); // Shuffle for randomness
    return "(Follow-up: " + pool.front() + ")";
}


void ResponseVariator::bulkTeachFromCSV(const std::string& filepath) {
    std::ifstream file(filepath);
    std::string line;
    while (std::getline(file, line)) {
        std::stringstream ss(line);
        std::string topic, response, scoreStr;
        if (std::getline(ss, topic, ',') && std::getline(ss, response, ',') && std::getline(ss, scoreStr)) {
            float score = std::stof(scoreStr);
            saveResponse(topic, response, score);
            knowledgeBase[topic].emplace_back(response, score);
            for (const auto& t : extractTopics(topic)) {
                topicMap[t].insert(response);
            }
        }
    }
}
